import requests
import pandas as pd
import pathlib
from bs4 import BeautifulSoup
from tkinter import *
from tkinter import messagebox
from datetime import datetime
import os
from fake_useragent import UserAgent
sets = {}
snils = []

      
def parser12():
  
   

   s = "/Users/mariibykova/Desktop/file2.txt"
   infile = open(s, 'r+') #cчитали файл file.txt
   lines = infile.readlines()
   i =0
   adres1=""

   while(i<len(lines)):
      if(lines[i].strip() == "1"):
         i+=1
      elif (lines[i].strip()=="4"):
         i+=1
      elif (lines[i].strip()=="2"):
         
         

         i+=1
      elif (lines[i].strip()=="3"):
         
         
         i+=1
      elif (lines[i].strip()=="4"):
         

         i+=1
      elif (lines[i].strip()=="5"):
         
        

         i+=1
      else:
         name = lines[i].strip()
         url = lines[i+1].strip()
         snils_pars(name, url,adres1)
         i +=2
   print(len(snils))
   f = open("/Users/mariibykova/Desktop/snils.txt", 'w')
   f.write(len(snils)+ '\n')
   for i in snils:
      f.write(str(i)+ '\n')
   messagebox.showinfo('ParserINFO', f'Файл с данными сформирован!')
   
   

def snils_pars(name, url, adres):
   global sets
   
   name = adres +"/"+  name
   UserAgent().chrome
   s1 = '.csv'            # строка с расширением (для формирования названия)
   page = requests.get(url, headers={'User-Agent': UserAgent().chrome}) 
   soup = BeautifulSoup(page.text, 'lxml') # получаем код html-cтраницы

   table1 = soup.find('table') # поиск первой таблицы
   k = 0
   mydata1 = pd.DataFrame() # определяем фрейм данных
   add = []
   rows = []
   for table1 in soup.find_all('table',): # пока на странице есть таблицы
      headers = [] # пустой список для колонок таблицы
      for i in table1.find_all('th'): # пока есть колонки
         title = i.text
         headers.append(title) # добавляем колонку в список
      mydata = pd.DataFrame(columns = headers)
      mydata3 = pd.DataFrame(columns = headers)
      length = 0
      k = 0
      row = ""
      for j in table1.find_all('tr')[1:]: # строка находится внутри тега <tr>
         row_data = j.find_all('td')     # элементы — внутри тега <td>
         row = [i.text for i in row_data] #получаем данные и сохраняем их
         rows.append(row)
         if (len(str(row[1]))==14 and not(row[1] in snils)):
            snils.append(row[1])
           #length = len(mydata)
           #mydata.loc[length] = row
           #mydata = mydata.append(row, ignore_index = False )
      
   
# оконное приложение
window = Tk() # cоздаём окно приложения
window.title('Parser snils SGU') # вызов функции парсеринга
window.geometry('600x300') # размеры окна
frame = Frame(
   window,  # обязательный параметр, указывающий окно для размещения Frame
   padx=10, # отступ по горизонтали
   pady=10  # отступ по вертикали
)
frame.pack(expand=True)

 
pars_btn = Button( # кнопка
   frame,
   text='Получить список снилсов',
   command=parser12,
)
pars_btn.grid(row=3, column=1)




def on_closing():
   if messagebox.askokcancel("Выход", "Вы хотите выйти?"):
      window.destroy()

window.protocol("WM_DELETE_WINDOW", on_closing)
window.mainloop() # вызов окна для взаимодействия с пользователем


